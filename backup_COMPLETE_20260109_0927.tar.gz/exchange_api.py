#!/usr/bin/env python3
import ccxt
from config import logger, EXCHANGES

class ExchangeAPI:
    def __init__(self):
        self.exchanges = {}
        for ex_id in EXCHANGES.keys():
            if ex_id == 'mexc':
                self.exchanges[ex_id] = ccxt.mexc()
            elif ex_id == 'bybit':
                self.exchanges[ex_id] = ccxt.bybit()
            elif ex_id == 'binance':
                self.exchanges[ex_id] = ccxt.binance()
    
    async def get_symbols(self, exchange: str):
        """Get all symbols from exchange"""
        try:
            ex = self.exchanges.get(exchange)
            if not ex:
                logger.error(f"Exchange {exchange} not found")
                return []
            
            # Load markets synchronously
            markets = ex.load_markets()
            
            # Filter USDT pairs
            symbols = [s for s in markets.keys() if '/USDT' in s]
            
            logger.info(f"Found {len(symbols)} symbols on {exchange}")
            
            return symbols[:500]  # Return max 500
            
        except Exception as e:
            logger.error(f"Get symbols error: {e}")
            return []
    
    async def get_ohlcv(self, exchange: str, symbol: str, timeframe: str, limit: int = 100):
        """Get OHLCV data"""
        try:
            ex = self.exchanges.get(exchange)
            if not ex:
                return None
            
            ohlcv = ex.fetch_ohlcv(symbol, timeframe, limit=limit)
            return ohlcv
            
        except Exception as e:
            logger.error(f"Get OHLCV error for {symbol}: {e}")
            return None
    
    async def get_ticker(self, exchange: str, symbol: str):
        """Get ticker data"""
        try:
            ex = self.exchanges.get(exchange)
            if not ex:
                return None
            
            ticker = ex.fetch_ticker(symbol)
            return ticker
            
        except Exception as e:
            logger.error(f"Get ticker error for {symbol}: {e}")
            return None

exchange_api = ExchangeAPI()
logger.info("✅ Exchange API initialized")
