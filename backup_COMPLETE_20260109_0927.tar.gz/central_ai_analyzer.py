#!/usr/bin/env python3
"""
CENTRALNY AI ANALYZER - Ultra zaawansowana analiza dla wszystkich funkcji bota
Łączy: Technical Analysis + DeepSeek AI + Perplexity News + Sentiment
"""
import asyncio
from datetime import datetime, timedelta
from config import logger
from exchange_api import exchange_api
import json

class CentralAIAnalyzer:
    def __init__(self):
        self.deepseek_enabled = True  # Later: integrate DeepSeek API
        self.perplexity_enabled = True  # Later: integrate Perplexity API
    
    async def analyze_pair_full(self, exchange: str, symbol: str, timeframe: str, context: str = 'general'):
        """
        GŁÓWNA FUNKCJA - Pełna analiza pary
        
        context: 'search', 'scan_extreme', 'ai_signal', 'general'
        """
        logger.info(f"Starting FULL analysis: {symbol} on {exchange} ({timeframe})")
        
        try:
            # 1. POBIERZ DANE
            ohlcv_data = await self._fetch_multi_timeframe_data(exchange, symbol, timeframe)
            ticker = await exchange_api.get_ticker(exchange, symbol)
            
            if not ohlcv_data or not ticker:
                return None
            
            # 2. TECHNICAL ANALYSIS (wszystkie wskaźniki)
            technical = self._technical_analysis(ohlcv_data, timeframe)
            
            # 3. MARKET STRUCTURE (S/R, patterns)
            structure = self._market_structure_analysis(ohlcv_data)
            
            # 4. VOLUME ANALYSIS
            volume_analysis = self._volume_analysis(ohlcv_data)
            
            # 5. SENTIMENT SCORE (z danych technicznych)
            sentiment = self._calculate_sentiment(technical, structure, volume_analysis)
            
            # 6. AI REASONING (później: DeepSeek)
            ai_reasoning = await self._ai_reasoning(
                symbol, technical, structure, volume_analysis, sentiment, context
            )
            
            # 7. NEWS & EVENTS (później: Perplexity)
            news_impact = await self._get_news_impact(symbol)
            
            # 8. GENERATE SIGNAL
            signal = self._generate_trading_signal(
                technical, structure, volume_analysis, sentiment, ai_reasoning, news_impact
            )
            
            # 9. COMPILE FULL REPORT
            report = {
                'symbol': symbol,
                'exchange': exchange,
                'timeframe': timeframe,
                'timestamp': datetime.now().isoformat(),
                'current_price': ohlcv_data['current'][4],
                'technical': technical,
                'structure': structure,
                'volume': volume_analysis,
                'sentiment': sentiment,
                'ai_reasoning': ai_reasoning,
                'news': news_impact,
                'signal': signal,
                'context': context
            }
            
            logger.info(f"Analysis complete: {symbol} - {signal['direction']} {signal['confidence']}%")
            
            return report
            
        except Exception as e:
            logger.error(f"Analysis error for {symbol}: {e}")
            return None
    
    async def _fetch_multi_timeframe_data(self, exchange, symbol, primary_tf):
        """Pobierz dane z wielu timeframe'ów"""
        try:
            # Primary timeframe (requested)
            primary = await exchange_api.get_ohlcv(exchange, symbol, primary_tf, 100)
            
            # Higher timeframe (trend context)
            higher_tf = self._get_higher_timeframe(primary_tf)
            higher = await exchange_api.get_ohlcv(exchange, symbol, higher_tf, 50)
            
            # Lower timeframe (entry precision)
            lower_tf = self._get_lower_timeframe(primary_tf)
            lower = await exchange_api.get_ohlcv(exchange, symbol, lower_tf, 200)
            
            return {
                'current': primary[-1] if primary else None,
                'primary': primary,
                'higher': higher,
                'lower': lower,
                'primary_tf': primary_tf,
                'higher_tf': higher_tf,
                'lower_tf': lower_tf
            }
        except:
            return None
    
    def _technical_analysis(self, data, timeframe):
        """Wszystkie wskaźniki techniczne"""
        primary = data['primary']
        
        if not primary or len(primary) < 50:
            return {}
        
        closes = [c[4] for c in primary]
        highs = [c[2] for c in primary]
        lows = [c[3] for c in primary]
        volumes = [c[5] for c in primary]
        
        # RSI (14, 7, 21)
        rsi_14 = self._calculate_rsi(closes, 14)
        rsi_7 = self._calculate_rsi(closes, 7)
        rsi_21 = self._calculate_rsi(closes, 21)
        
        # EMA (9, 21, 50, 200)
        ema_9 = self._calculate_ema(closes, 9)
        ema_21 = self._calculate_ema(closes, 21)
        ema_50 = self._calculate_ema(closes, 50)
        ema_200 = self._calculate_ema(closes, 200) if len(closes) >= 200 else None
        
        # MACD
        macd = self._calculate_macd(closes)
        
        # Bollinger Bands
        bb = self._calculate_bollinger_bands(closes)
        
        # ATR (volatility)
        atr = self._calculate_atr(highs, lows, closes)
        
        # Stochastic
        stoch = self._calculate_stochastic(highs, lows, closes)
        
        # ADX (trend strength)
        adx = self._calculate_adx(highs, lows, closes)
        
        current_price = closes[-1]
        
        return {
            'price': current_price,
            'rsi': {'14': rsi_14, '7': rsi_7, '21': rsi_21},
            'ema': {'9': ema_9, '21': ema_21, '50': ema_50, '200': ema_200},
            'macd': macd,
            'bollinger': bb,
            'atr': atr,
            'stochastic': stoch,
            'adx': adx,
            'change_24h': ((current_price - closes[-24]) / closes[-24] * 100) if len(closes) >= 24 else 0
        }
    
    def _market_structure_analysis(self, data):
        """Support/Resistance, patterns, trend"""
        primary = data['primary']
        
        if not primary or len(primary) < 50:
            return {}
        
        closes = [c[4] for c in primary]
        highs = [c[2] for c in primary]
        lows = [c[3] for c in primary]
        
        # Find S/R levels
        support_levels = self._find_support_levels(lows, closes[-1])
        resistance_levels = self._find_resistance_levels(highs, closes[-1])
        
        # Trend direction
        trend = self._identify_trend(closes)
        
        # Chart patterns (simplified)
        patterns = self._detect_patterns(closes, highs, lows)
        
        return {
            'support': support_levels[:3],  # Top 3
            'resistance': resistance_levels[:3],
            'trend': trend,
            'patterns': patterns
        }
    
    def _volume_analysis(self, data):
        """Volume profile, buying/selling pressure"""
        primary = data['primary']
        
        if not primary:
            return {}
        
        volumes = [c[5] for c in primary]
        closes = [c[4] for c in primary]
        opens = [c[1] for c in primary]
        
        avg_volume = sum(volumes[-20:]) / 20
        current_volume = volumes[-1]
        volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
        
        # Buying vs selling pressure
        buy_volume = sum([volumes[i] for i in range(-20, 0) if closes[i] > opens[i]])
        sell_volume = sum([volumes[i] for i in range(-20, 0) if closes[i] < opens[i]])
        
        buy_pressure = (buy_volume / (buy_volume + sell_volume) * 100) if (buy_volume + sell_volume) > 0 else 50
        
        return {
            'current': current_volume,
            'average': avg_volume,
            'ratio': volume_ratio,
            'buy_pressure': buy_pressure,
            'sell_pressure': 100 - buy_pressure
        }
    
    def _calculate_sentiment(self, technical, structure, volume):
        """Oblicz ogólny sentyment rynku dla pary"""
        score = 0
        signals = []
        
        # RSI sentiment
        rsi = technical.get('rsi', {}).get('14', 50)
        if rsi < 30:
            score += 30
            signals.append('Oversold')
        elif rsi < 40:
            score += 15
            signals.append('Low RSI')
        elif rsi > 70:
            score -= 30
            signals.append('Overbought')
        elif rsi > 60:
            score -= 15
            signals.append('High RSI')
        
        # EMA trend sentiment
        ema = technical.get('ema', {})
        if ema.get('9') and ema.get('21') and ema.get('50'):
            if ema['9'] > ema['21'] > ema['50']:
                score += 25
                signals.append('Strong uptrend')
            elif ema['9'] < ema['21'] < ema['50']:
                score -= 25
                signals.append('Strong downtrend')
        
        # Volume sentiment
        vol = volume.get('ratio', 1)
        if vol > 2:
            score += 15
            signals.append('High volume')
        
        buy_pressure = volume.get('buy_pressure', 50)
        if buy_pressure > 65:
            score += 10
            signals.append('Buying pressure')
        elif buy_pressure < 35:
            score -= 10
            signals.append('Selling pressure')
        
        # Trend sentiment
        trend = structure.get('trend', {}).get('direction', 'neutral')
        if trend == 'strong_bullish':
            score += 20
        elif trend == 'strong_bearish':
            score -= 20
        
        # Normalize score to -100 to +100
        score = max(-100, min(100, score))
        
        if score > 50:
            sentiment_label = '🟢 Very Bullish'
        elif score > 20:
            sentiment_label = '🟢 Bullish'
        elif score > -20:
            sentiment_label = '⚪ Neutral'
        elif score > -50:
            sentiment_label = '🔴 Bearish'
        else:
            sentiment_label = '🔴 Very Bearish'
        
        return {
            'score': score,
            'label': sentiment_label,
            'signals': signals
        }
    
    async def _ai_reasoning(self, symbol, technical, structure, volume, sentiment, context):
        """AI reasoning - później DeepSeek"""
        # PLACEHOLDER - później integr with DeepSeek
        
        reasoning = []
        
        # Based on technical
        rsi = technical.get('rsi', {}).get('14', 50)
        if rsi < 35:
            reasoning.append("RSI shows oversold conditions, potential bounce opportunity")
        elif rsi > 65:
            reasoning.append("RSI indicates overbought, possible correction incoming")
        
        # Based on structure
        trend = structure.get('trend', {}).get('direction', 'neutral')
        if 'bullish' in trend:
            reasoning.append("Price respects higher timeframe uptrend")
        elif 'bearish' in trend:
            reasoning.append("Downtrend remains intact on HTF")
        
        # Based on volume
        if volume.get('ratio', 1) > 2:
            reasoning.append("Unusual volume spike suggests strong interest")
        
        return {
            'summary': reasoning,
            'confidence': self._calculate_reasoning_confidence(technical, structure, volume),
            'source': 'Technical Analysis'  # Later: 'DeepSeek AI'
        }
    
    async def _get_news_impact(self, symbol):
        """News & events - później Perplexity"""
        # PLACEHOLDER - później integration with Perplexity
        
        return {
            'recent_news': [],
            'sentiment': 'neutral',
            'impact_score': 0,
            'source': 'None'  # Later: 'Perplexity AI'
        }
    
    def _generate_trading_signal(self, technical, structure, volume, sentiment, ai_reasoning, news):
        """Generate final trading signal"""
        
        # Determine direction
        sent_score = sentiment['score']
        
        if sent_score > 30:
            direction = 'LONG'
        elif sent_score < -30:
            direction = 'SHORT'
        else:
            direction = 'NEUTRAL'
        
        # Calculate confidence (0-100)
        confidence = self._calculate_signal_confidence(
            technical, structure, volume, sentiment, ai_reasoning
        )
        
        # Calculate TP/SL levels
        current_price = technical['price']
        atr = technical.get('atr', current_price * 0.02)
        
        if direction == 'LONG':
            entry = current_price
            tp1 = current_price + (atr * 1.5)
            tp2 = current_price + (atr * 3)
            tp3 = current_price + (atr * 5)
            sl = current_price - (atr * 2)
        elif direction == 'SHORT':
            entry = current_price
            tp1 = current_price - (atr * 1.5)
            tp2 = current_price - (atr * 3)
            tp3 = current_price - (atr * 5)
            sl = current_price + (atr * 2)
        else:
            entry = tp1 = tp2 = tp3 = sl = current_price
        
        # Risk/Reward
        if direction != 'NEUTRAL':
            risk = abs(entry - sl)
            reward = abs(tp2 - entry)
            rr_ratio = reward / risk if risk > 0 else 0
        else:
            rr_ratio = 0
        
        return {
            'direction': direction,
            'confidence': confidence,
            'entry': entry,
            'tp1': tp1,
            'tp2': tp2,
            'tp3': tp3,
            'sl': sl,
            'rr_ratio': rr_ratio,
            'reasons': sentiment['signals'] + ai_reasoning['summary'][:3]
        }
    
    # HELPER FUNCTIONS (indicators)
    
    def _calculate_rsi(self, closes, period=14):
        if len(closes) < period:
            return 50
        deltas = [closes[i] - closes[i-1] for i in range(1, len(closes))]
        gains = [d if d > 0 else 0 for d in deltas[-period:]]
        losses = [-d if d < 0 else 0 for d in deltas[-period:]]
        avg_gain = sum(gains) / period
        avg_loss = sum(losses) / period
        if avg_loss == 0:
            return 100
        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))
    
    def _calculate_ema(self, closes, period):
        if len(closes) < period:
            return closes[-1]
        multiplier = 2 / (period + 1)
        ema = closes[0]
        for price in closes[1:]:
            ema = (price - ema) * multiplier + ema
        return ema
    
    def _calculate_macd(self, closes):
        ema_12 = self._calculate_ema(closes, 12)
        ema_26 = self._calculate_ema(closes, 26)
        macd_line = ema_12 - ema_26
        # Signal line (9 EMA of MACD) - simplified
        signal_line = macd_line * 0.9
        histogram = macd_line - signal_line
        return {'macd': macd_line, 'signal': signal_line, 'histogram': histogram}
    
    def _calculate_bollinger_bands(self, closes, period=20):
        if len(closes) < period:
            return {}
        sma = sum(closes[-period:]) / period
        variance = sum([(c - sma) ** 2 for c in closes[-period:]]) / period
        std_dev = variance ** 0.5
        return {
            'upper': sma + (2 * std_dev),
            'middle': sma,
            'lower': sma - (2 * std_dev)
        }
    
    def _calculate_atr(self, highs, lows, closes, period=14):
        if len(closes) < period:
            return (highs[-1] - lows[-1])
        true_ranges = []
        for i in range(1, len(closes)):
            tr = max(
                highs[i] - lows[i],
                abs(highs[i] - closes[i-1]),
                abs(lows[i] - closes[i-1])
            )
            true_ranges.append(tr)
        return sum(true_ranges[-period:]) / period
    
    def _calculate_stochastic(self, highs, lows, closes, period=14):
        if len(closes) < period:
            return 50
        lowest_low = min(lows[-period:])
        highest_high = max(highs[-period:])
        if highest_high == lowest_low:
            return 50
        k = ((closes[-1] - lowest_low) / (highest_high - lowest_low)) * 100
        return k
    
    def _calculate_adx(self, highs, lows, closes, period=14):
        # Simplified ADX
        if len(closes) < period:
            return 20
        # Placeholder - real ADX is complex
        return 25
    
    def _find_support_levels(self, lows, current_price):
        # Find recent lows as support
        supports = sorted(set([l for l in lows[-50:] if l < current_price]))
        return supports[-5:] if supports else []
    
    def _find_resistance_levels(self, highs, current_price):
        # Find recent highs as resistance
        resistances = sorted(set([h for h in highs[-50:] if h > current_price]))
        return resistances[:5] if resistances else []
    
    def _identify_trend(self, closes):
        if len(closes) < 50:
            return {'direction': 'neutral', 'strength': 0}
        
        recent = closes[-20:]
        older = closes[-50:-30]
        
        recent_avg = sum(recent) / len(recent)
        older_avg = sum(older) / len(older)
        
        change = ((recent_avg - older_avg) / older_avg) * 100
        
        if change > 5:
            return {'direction': 'strong_bullish', 'strength': min(change, 100)}
        elif change > 2:
            return {'direction': 'bullish', 'strength': change}
        elif change < -5:
            return {'direction': 'strong_bearish', 'strength': abs(change)}
        elif change < -2:
            return {'direction': 'bearish', 'strength': abs(change)}
        else:
            return {'direction': 'neutral', 'strength': 0}
    
    def _detect_patterns(self, closes, highs, lows):
        # Simplified pattern detection
        patterns = []
        
        # Double bottom/top (simplified)
        if len(lows) >= 20:
            recent_lows = lows[-20:]
            if min(recent_lows[-5:]) > min(recent_lows[-15:-10]):
                patterns.append('Potential Double Bottom')
        
        return patterns
    
    def _calculate_reasoning_confidence(self, technical, structure, volume):
        # Calculate AI reasoning confidence
        score = 50  # Base
        
        # Strong indicators add confidence
        rsi = technical.get('rsi', {}).get('14', 50)
        if rsi < 25 or rsi > 75:
            score += 15
        
        vol_ratio = volume.get('ratio', 1)
        if vol_ratio > 2:
            score += 10
        
        trend = structure.get('trend', {}).get('strength', 0)
        if trend > 5:
            score += 10
        
        return min(score, 95)
    
    def _calculate_signal_confidence(self, technical, structure, volume, sentiment, ai_reasoning):
        # Final signal confidence
        base = abs(sentiment['score'])  # 0-100
        
        # Boost from AI reasoning
        ai_conf = ai_reasoning.get('confidence', 50)
        
        # Average weighted
        confidence = (base * 0.6) + (ai_conf * 0.4)
        
        return min(int(confidence), 95)
    
    def _get_higher_timeframe(self, tf):
        mapping = {
            '1m': '5m', '3m': '15m', '5m': '15m', '15m': '1h',
            '30m': '4h', '1h': '4h', '2h': '1d', '4h': '1d',
            '8h': '1d', '12h': '1d', '1d': '1w', '3d': '1w',
            '1w': '1M', '2w': '1M', '1M': '3M'
        }
        return mapping.get(tf, '1d')
    
    def _get_lower_timeframe(self, tf):
        mapping = {
            '5m': '1m', '15m': '5m', '30m': '15m', '1h': '15m',
            '4h': '1h', '1d': '4h', '1w': '1d', '1M': '1w'
        }
        return mapping.get(tf, tf)

central_analyzer = CentralAIAnalyzer()
logger.info("✅ Central AI Analyzer initialized")
