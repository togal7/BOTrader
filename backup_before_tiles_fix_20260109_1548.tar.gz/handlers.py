#!/usr/bin/env python3
import asyncio
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from config import logger, ADMIN_IDS, EXCHANGES, TIMEFRAMES, USDT_ADDRESS
from database import db
from exchange_api import exchange_api
from ai_trader import ai_trader
import json

# ==========================================
# HELPER FUNCTIONS
# ==========================================
def format_subscription_status(subscription_expires, is_blocked=False):
    """Format subscription status"""
    if is_blocked:
        return '🚫 Zablokowany'
    
    if not subscription_expires:
        return '⚠️ Brak subskrypcji (0 dni)'
    
    try:
        expires_date = datetime.fromisoformat(subscription_expires)
        days_left = (expires_date - datetime.now()).days
        
        if days_left <= 0:
            return '❌ Wygasła (0 dni)'
        elif days_left <= 7:
            return f'⚠️ Premium ({days_left} dni)'
        else:
            return f'✅ Premium ({days_left} dni)'
    except:
        return '⚠️ Brak subskrypcji'

def back_button(callback_data='back_main'):
    """Universal back button"""
    return InlineKeyboardMarkup([[InlineKeyboardButton('⬅️ Powrót', callback_data=callback_data)]])

# ==========================================
# START COMMAND
# ==========================================
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start command - main menu"""
    user = update.effective_user
    user_id = user.id
    
    # Get or create user
    user_data = db.get_user(user_id)
    if not user_data:
        user_data = {
            'user_id': user_id,
            'username': user.username or 'Unknown',
            'first_name': user.first_name or '',
            'selected_exchange': 'mexc',
            'interval': '15m',
            'is_premium': False,
            'subscription_expires': None,
            'is_blocked': False,
            'signals_count': 0,
            'last_active': datetime.now().isoformat()
        }
        db.add_user(user_data)
    else:
        user_data['last_active'] = datetime.now().isoformat()
        db.update_user(user_id, user_data)
    
    sub_status = format_subscription_status(user_data.get('subscription_expires'), user_data.get('is_blocked', False))
    is_admin = user_id in ADMIN_IDS
    
    lang = get_user_language(user_data)
    
    welcome = f"""👋 {t('welcome', lang)}

{t('your_status', lang)}: {sub_status}
🆔 ID: {user_id}

✨ {t('possibilities', lang)}:
🔍 {t('search_desc', lang)}
📊 {t('scan_desc', lang)}
🎯 {t('ai_desc', lang)}
⚙️ {t('settings_desc', lang)}"""

    keyboard = [
        [InlineKeyboardButton(t('search_pair', lang), callback_data='search_pair')],
        [InlineKeyboardButton(t('scan_extremes', lang), callback_data='scan_extremes')],
        [InlineKeyboardButton(t('ai_signals', lang), callback_data='ai_signals')],
        [InlineKeyboardButton(t('settings', lang), callback_data='settings')],
        [InlineKeyboardButton(t('subscription', lang), callback_data='subscription')],
        [InlineKeyboardButton(t('admin_chat', lang), callback_data='admin_chat')],
        [InlineKeyboardButton(t('rate_bot', lang), callback_data='rate_bot')]
    ]
    
    if is_admin:
        keyboard.append([InlineKeyboardButton("👨‍💼 Admin", callback_data='admin_panel')])
    
    keyboard.append([
        InlineKeyboardButton("📊 MEXC", url='https://promote.mexc.com/r/gspEf2nl'),
        InlineKeyboardButton("📊 Bybit", url='https://www.bybit.com/invite?ref=64NXL'),
        InlineKeyboardButton("📊 Binance", url='https://www.binance.com/activity/referral-entry/CPA?ref=CPA_00J86WYYZV')
    ])
    
    await update.message.reply_text(welcome, reply_markup=InlineKeyboardMarkup(keyboard))

# ==========================================
# BUTTON CALLBACK HANDLER
# ==========================================
async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle all button callbacks"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    user = db.get_user(user_id)
    
    if not user:
        await query.edit_message_text("❌ Użytkownik nie znaleziony. Wyślij /start")
        return
    
    data = query.data
    
    user['last_active'] = datetime.now().isoformat()
    db.update_user(user_id, user)
    
    if data == 'back_main':
        await start_command_from_callback(query, user_id, user)
        return
    
    elif data == 'search_pair':
        await search_pair_menu(query, user_id, user)
        return
    
    elif data == 'ai_signals':
        await ai_signals_menu_advanced(query, user_id, user)
        return
    
    elif data.startswith('ai_scan_'):
        timeframe = data.replace('ai_scan_', '')
        await ai_scan_select_size(query, user_id, user, timeframe)
        return
    
    elif data.startswith('ai_run_'):
        parts = data.replace('ai_run_', '').split('_')
        timeframe = parts[0]
        scan_size = parts[1] if len(parts) > 1 else 'top10'
        await ai_scan_execute(query, user_id, user, timeframe, scan_size)
        return
    

    
    elif data == 'rate_bot':
        await rate_bot_menu(query, user_id, user)
        return
    
    elif data.startswith('rate_'):
        stars = data.replace('rate_', '')
        await query.answer(f"✅ Dziękujemy za {'⭐' * int(stars)}!")
        await start_command_from_callback(query, user_id, user)
        return
    
    elif data == 'scan_extremes':
        await scan_extremes_menu(query, user_id, user)
        return
    
    elif data.startswith('scan_'):
        await handle_scan(query, user_id, user, data)
        return
    
    elif data == 'settings':
        await settings_menu(query, user_id, user)
        return
    
    elif data == 'change_exchange':
        await change_exchange_menu(query, user_id, user)
        return
    
    elif data.startswith('set_exchange_'):
        exchange = data.replace('set_exchange_', '')
        user['selected_exchange'] = exchange
        db.update_user(user_id, user)
        await query.answer(f"✅ Zmieniono na {EXCHANGES[exchange]['name']}")
        await settings_menu(query, user_id, user)
        return
    
    elif data == 'change_interval':
        await change_interval_menu(query, user_id, user)
        return
    
    elif data.startswith('set_interval_'):
        interval = data.replace('set_interval_', '')
        user['interval'] = interval
        db.update_user(user_id, user)
        await query.answer(f"✅ Zmieniono na {TIMEFRAMES[interval]['label']}")
        await settings_menu(query, user_id, user)
        return
    
    elif data == 'language_menu':
        await language_menu(query, user_id, user)
        return
    
    elif data.startswith('set_lang_'):
        lang = data.replace('set_lang_', '')
        user['language'] = lang
        db.update_user(user_id, user)
        from languages import LANGUAGES
        await query.answer(f"✅ Language changed to {LANGUAGES[lang]['name']}")
        await settings_menu(query, user_id, user)
        return
    
    elif data == 'subscription':
        await subscription_menu(query, user_id, user)
        return
    
    elif data == 'payment_info':
        await payment_info_menu(query, user_id, user)
        return
    
    elif data == 'alerts_menu':
        await alerts_menu(query, user_id, user)
        return
    
    elif data == 'admin_chat':
        await admin_chat_menu(query, user_id, user)
        return
    
    elif data == 'admin_panel':
        if user_id not in ADMIN_IDS:
            await query.answer("❌ Brak dostępu")
            return
        await admin_panel_menu(query, user_id, user)
        return
    
    elif data == 'admin_stats':
        await admin_stats_menu(query, user_id, user)
        return
    
    elif data == 'admin_add_days':
        await admin_add_days_menu(query, user_id, user)
        return
    
    elif data.startswith('admin_user_'):
        target_uid = int(data.replace('admin_user_', ''))
        await admin_user_manage(query, user_id, target_uid)
        return
    
    elif data.startswith('admin_give_'):
        parts = data.replace('admin_give_', '').split('_')
        target_uid = int(parts[0])
        days = int(parts[1])
        await admin_give_days(query, user_id, target_uid, days)
        return
    
    elif data.startswith('admin_promo_all_'):
        days = int(data.replace('admin_promo_all_', ''))
        await admin_promo_all(query, user_id, days)
        return
    
    elif data == 'ignore':
        await query.answer()
        return
    
    elif data.startswith('analyze_'):
        # analyze_SYMBOL_TIMEFRAME lub analyze_SYMBOL (default 15m)
        parts = data.replace('analyze_', '').split('_')
        symbol = parts[0]
        timeframe = parts[1] if len(parts) > 1 else user.get('interval', '15m')
        exchange = user.get('selected_exchange', 'mexc').lower()
        
        await show_pair_analysis(query, user_id, user, symbol, exchange, timeframe, 'manual')
        return
    
    elif data.startswith('details_'):
        # Pokazuje więcej szczegółów
        parts = data.replace('details_', '').split('_')
        symbol = parts[0]
        timeframe = parts[1] if len(parts) > 1 else '15m'
        await query.answer("🔧 Szczegółowa analiza - w przygotowaniu!")
        return

# ==========================================
# SCAN EXTREMES
# ==========================================
async def scan_extremes_menu(query, user_id, user):
    """Scan extremes menu"""
    text = """📊 SKANER EKSTREMÓW

Wybierz typ skanowania:

🚀 Wzrosty - największe wzrosty ceny
📉 Spadki - największe spadki ceny
🔥 RSI < 30 - oversold
💎 RSI > 70 - overbought
📈 Volume - największy wolumen"""
    
    keyboard = [
        [InlineKeyboardButton("🚀 Wzrosty", callback_data='scan_gainers')],
        [InlineKeyboardButton("📉 Spadki", callback_data='scan_losers')],
        [InlineKeyboardButton("🔥 RSI Oversold", callback_data='scan_rsi_oversold')],
        [InlineKeyboardButton("💎 RSI Overbought", callback_data='scan_rsi_overbought')],
        [InlineKeyboardButton("📈 Volume TOP", callback_data='scan_volume')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def handle_scan(query, user_id, user, scan_type):
    """Handle scanning"""
    exchange = user.get('selected_exchange', 'mexc').lower()
    interval = user.get('interval', '15m')
    
    await query.edit_message_text(f"🔍 Skanuję {EXCHANGES[exchange]['name']}...\n\nCzekaj...")
    
    try:
        symbols = await exchange_api.get_symbols(exchange)
        
        if not symbols:
            await query.edit_message_text("❌ Błąd pobierania par", reply_markup=back_button('scan_extremes'))
            return
        
        results = []
        
        for symbol in list(symbols)[:50]:
            try:
                data = await exchange_api.get_ohlcv(exchange, symbol, interval)
                
                if not data or len(data) < 2:
                    continue
                
                current_price = data[-1][4]
                prev_price = data[-2][4]
                change_pct = ((current_price - prev_price) / prev_price) * 100
                
                closes = [candle[4] for candle in data[-14:]]
                gains = [closes[i] - closes[i-1] for i in range(1, len(closes)) if closes[i] > closes[i-1]]
                losses = [closes[i-1] - closes[i] for i in range(1, len(closes)) if closes[i] < closes[i-1]]
                
                avg_gain = sum(gains) / len(gains) if gains else 0
                avg_loss = sum(losses) / len(losses) if losses else 0
                
                if avg_loss == 0:
                    rsi = 100
                else:
                    rs = avg_gain / avg_loss
                    rsi = 100 - (100 / (1 + rs))
                
                volume = data[-1][5]
                
                result = {
                    'symbol': symbol,
                    'price': current_price,
                    'change': change_pct,
                    'rsi': rsi,
                    'volume': volume
                }
                
                if scan_type == 'scan_gainers' and change_pct > 0:
                    results.append(result)
                elif scan_type == 'scan_losers' and change_pct < 0:
                    results.append(result)
                elif scan_type == 'scan_rsi_oversold' and rsi < 30:
                    results.append(result)
                elif scan_type == 'scan_rsi_overbought' and rsi > 70:
                    results.append(result)
                elif scan_type == 'scan_volume':
                    results.append(result)
                
            except Exception as e:
                logger.error(f"Scan error for {symbol}: {e}")
                continue
        
        if not results:
            await query.edit_message_text("❌ Brak wyników", reply_markup=back_button('scan_extremes'))
            return
        
        if scan_type in ['scan_gainers', 'scan_losers']:
            results.sort(key=lambda x: abs(x['change']), reverse=True)
        elif scan_type in ['scan_rsi_oversold', 'scan_rsi_overbought']:
            results.sort(key=lambda x: x['rsi'])
        elif scan_type == 'scan_volume':
            results.sort(key=lambda x: x['volume'], reverse=True)
        
        top_results = results[:10]
        
        scan_names = {
            'scan_gainers': '🚀 WZROSTY',
            'scan_losers': '📉 SPADKI',
            'scan_rsi_oversold': '🔥 RSI < 30',
            'scan_rsi_overbought': '💎 RSI > 70',
            'scan_volume': '📈 VOLUME TOP'
        }
        
        text = f"{scan_names.get(scan_type, 'SKANER')}\n{EXCHANGES[exchange]['name']} | {TIMEFRAMES[interval]['label']}\n\n"
        text += f"Znaleziono: {len(results)} par\nTop 10:\n"
        
        keyboard = []
        
        for r in top_results:
            symbol = r['symbol']
            price = r['price']
            change = r['change']
            rsi = r['rsi']
            
            if scan_type in ['scan_gainers', 'scan_losers']:
                label = f"{'🟢' if change > 0 else '🔴'} {symbol} | {change:+.2f}%"
            else:
                label = f"📊 {symbol} | RSI {rsi:.0f}"
            
            keyboard.append([InlineKeyboardButton(label, callback_data=f'analyze_{symbol}')])
        
        keyboard.append([InlineKeyboardButton('🔄 Odśwież', callback_data=scan_type)])
        keyboard.append([InlineKeyboardButton('⬅️ Powrót', callback_data='scan_extremes')])
        
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        
        user['signals_count'] = user.get('signals_count', 0) + 1
        db.update_user(user_id, user)
        
    except Exception as e:
        logger.error(f"Scan error: {e}")
        await query.edit_message_text(f"❌ Błąd: {e}", reply_markup=back_button('scan_extremes'))

# ==========================================
# SETTINGS
# ==========================================
async def settings_menu(query, user_id, user):
    """Settings menu"""
    exchange = user.get('selected_exchange', 'mexc').lower()
    interval = user.get('interval', '15m')
    
    lang = get_user_language(user)
    
    text = f"""⚙️ {t('settings', lang).upper()}

🌐 {t('exchange', lang)}: {EXCHANGES[exchange]['name']}
⏰ {t('interval', lang)}: {TIMEFRAMES[interval]['label']}"""
    
    keyboard = [
        [InlineKeyboardButton("🌍 Język / Language", callback_data='language_menu')],
        [InlineKeyboardButton(t('change_exchange', lang), callback_data='change_exchange')],
        [InlineKeyboardButton(t('change_interval', lang), callback_data='change_interval')],
        [InlineKeyboardButton(t('back', lang), callback_data='back_main')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def change_exchange_menu(query, user_id, user):
    """Change exchange"""
    text = "🌐 WYBIERZ GIEŁDĘ\n\nDostępne giełdy:"
    
    keyboard = []
    for ex_id, ex_data in EXCHANGES.items():
        keyboard.append([InlineKeyboardButton(f"{ex_data['name']}", callback_data=f'set_exchange_{ex_id}')])
    
    keyboard.append([InlineKeyboardButton('⬅️ Powrót', callback_data='settings')])
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def change_interval_menu(query, user_id, user):
    """Change interval"""
    text = "⏰ WYBIERZ INTERWAŁ\n\nDostępne:"
    
    keyboard = []
    for tf_id, tf_data in TIMEFRAMES.items():
        keyboard.append([InlineKeyboardButton(f"{tf_data['label']}", callback_data=f'set_interval_{tf_id}')])
    
    keyboard.append([InlineKeyboardButton('⬅️ Powrót', callback_data='settings')])
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

# ==========================================
# SUBSCRIPTION
# ==========================================
async def subscription_menu(query, user_id, user):
    """Subscription menu"""
    sub_status = format_subscription_status(user.get('subscription_expires'), user.get('is_blocked', False))
    
    text = f"""💎 SUBSKRYPCJA

🆔 ID: {user_id}
📅 Status: {sub_status}

✨ PREMIUM:
• 🎯 Nielimitowane sygnały AI
• 🔔 Nielimitowane alerty
• 📊 16 timeframe'ów
• 🚀 Priorytet wsparcia

💰 PAKIETY:
• 7 dni - 50 PLN / 12 USDT
• 30 dni - 150 PLN / 35 USDT ⭐
• 90 dni - 350 PLN / 80 USDT 🔥 -20%
• 365 dni - 1000 PLN / 230 USDT 💎 -50%

💬 Kontakt: @YOUR_ADMIN"""
    
    keyboard = [
        [InlineKeyboardButton("💳 Metody płatności", callback_data='payment_info')],
        [InlineKeyboardButton("💬 Kontakt z adminem", callback_data='admin_chat')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def payment_info_menu(query, user_id, user):
    """Payment info"""
    text = f"""💳 METODY PŁATNOŚCI

🏦 BLIK / Przelew bankowy (PLN)
   → Szybki kontakt z adminem

💎 USDT (TRC20)
   → Adres: `{USDT_ADDRESS}`
   → Natychmiastowa aktywacja

📝 Proces:
1. Wybierz pakiet
2. Napisz do admina
3. Wyślij płatność
4. Aktywacja!

💬 Kontakt: @YOUR_ADMIN"""
    
    keyboard = [
        [InlineKeyboardButton("💬 Napisz do admina", callback_data='admin_chat')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='subscription')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

# ==========================================
# ALERTS
# ==========================================
async def alerts_menu(query, user_id, user):
    """Alerts menu"""
    text = """🔔 ALERTY

Funkcja w przygotowaniu!

Wkrótce dostępne:
• 💰 Alert cenowy
• 📊 Alert RSI
• 📈 Alert MACD

Zostaniesz powiadomiony! 🚀"""
    
    keyboard = [[InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

# ==========================================
# ADMIN CHAT
# ==========================================
async def admin_chat_menu(query, user_id, user):
    """Admin chat"""
    text = f"""💬 CZAT Z ADMINEM

🆔 Twoje ID: {user_id}

Napisz swoją wiadomość w następnej wiadomości.
Admin odpowie bezpośrednio.

📝 Możesz wysłać:
• Tekst
• Zdjęcia
• Dokumenty"""
    
    keyboard = [[InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
    
    user['awaiting_admin_message'] = True
    db.update_user(user_id, user)

# ==========================================
# ADMIN PANEL
# ==========================================
async def admin_panel_menu(query, user_id, user):
    """Admin panel"""
    if user_id not in ADMIN_IDS:
        await query.answer("❌ Brak dostępu")
        return
    
    total_users = db.get_user_count()
    active_users = len(db.get_active_users(7))
    
    text = f"""👨‍💼 PANEL ADMINA

📊 Statystyki:
• Użytkownicy: {total_users}
• Aktywni (7 dni): {active_users}

⚙️ Zarządzanie:"""
    
    keyboard = [
        [InlineKeyboardButton("📊 Statystyki", callback_data='admin_stats')],
        [InlineKeyboardButton("➕ Dodaj dni", callback_data='admin_add_days')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def admin_stats_menu(query, user_id, user):
    """Admin statistics"""
    all_users = db.get_all_users()
    total = len(all_users)
    active_7d = len(db.get_active_users(7))
    premium = sum(1 for u in all_users if u.get('is_premium', False))
    total_signals = sum(u.get('signals_count', 0) for u in all_users)
    
    text = f"""📊 STATYSTYKI

👥 Użytkownicy:
• Wszyscy: {total}
• Aktywni 7d: {active_7d}
• Premium: {premium}

📈 Aktywność:
• Sygnały: {total_signals}
• Średnio/user: {total_signals / total if total > 0 else 0:.1f}"""
    
    keyboard = [[InlineKeyboardButton('⬅️ Powrót', callback_data='admin_panel')]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def admin_add_days_menu(query, user_id, user):
    """Add days - show users list"""
    all_users = db.get_all_users()
    all_users.sort(key=lambda u: u.get('last_active', ''), reverse=True)
    
    text = f"""➕ DODAJ DNI SUBSKRYPCJI

👥 Użytkowników: {len(all_users)}

Kliknij użytkownika:"""
    
    keyboard = []
    
    keyboard.append([InlineKeyboardButton('🎁 +7 dni WSZYSTKIM', callback_data='admin_promo_all_7')])
    keyboard.append([InlineKeyboardButton('🎁 +30 dni WSZYSTKIM', callback_data='admin_promo_all_30')])
    keyboard.append([InlineKeyboardButton('─────────────', callback_data='ignore')])
    
    for u in all_users[:15]:
        uid = u['user_id']
        username = u.get('username', 'Brak')
        
        sub_expires = u.get('subscription_expires')
        is_premium = u.get('is_premium', False)
        
        if is_premium and sub_expires:
            try:
                expires_date = datetime.fromisoformat(sub_expires)
                days_left = (expires_date - datetime.now()).days
                status = f"💎 {days_left}d"
            except:
                status = "⚠️ 0d"
        else:
            status = "⚠️ 0d"
        
        keyboard.append([InlineKeyboardButton(
            f"{status} {uid} @{username}",
            callback_data=f"admin_user_{uid}"
        )])
    
    keyboard.append([InlineKeyboardButton('⬅️ Powrót', callback_data='admin_panel')])
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def admin_user_manage(query, user_id, target_user_id):
    """Manage specific user"""
    if user_id not in ADMIN_IDS:
        return
    
    target_user = db.get_user(target_user_id)
    username = target_user.get('username', 'Brak')
    
    sub_expires = target_user.get('subscription_expires')
    is_premium = target_user.get('is_premium', False)
    
    if is_premium and sub_expires:
        try:
            expires_date = datetime.fromisoformat(sub_expires)
            days_left = (expires_date - datetime.now()).days
            status = f"💎 {days_left} dni"
        except:
            status = "⚠️ Brak"
    else:
        status = "⚠️ Brak"
    
    text = f"""👤 ZARZĄDZAJ

🆔 ID: {target_user_id}
👤 @{username}
📅 Status: {status}

Wybierz akcję:"""
    
    keyboard = [
        [InlineKeyboardButton('➕ +7 dni', callback_data=f'admin_give_{target_user_id}_7')],
        [InlineKeyboardButton('➕ +30 dni', callback_data=f'admin_give_{target_user_id}_30')],
        [InlineKeyboardButton('➕ +90 dni', callback_data=f'admin_give_{target_user_id}_90')],
        [InlineKeyboardButton('➕ +365 dni', callback_data=f'admin_give_{target_user_id}_365')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='admin_add_days')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def admin_give_days(query, user_id, target_user_id, days):
    """Give days to user"""
    if user_id not in ADMIN_IDS:
        return
    
    target_user = db.get_user(target_user_id)
    
    current_expires = target_user.get('subscription_expires')
    if current_expires:
        try:
            expires_date = datetime.fromisoformat(current_expires)
        except:
            expires_date = datetime.now()
    else:
        expires_date = datetime.now()
    
    new_expires = expires_date + timedelta(days=days)
    
    target_user['subscription_expires'] = new_expires.isoformat()
    target_user['is_premium'] = True
    db.update_user(target_user_id, target_user)
    
    try:
        await query.bot.send_message(
            chat_id=target_user_id,
            text=f"""🎉 GRATULACJE!

Admin dodał Ci {days} dni Premium!

💎 Data wygaśnięcia: {new_expires.strftime('%Y-%m-%d')}

Dziękujemy! ❤️"""
        )
    except:
        pass
    
    await query.answer(f"✅ Dodano {days} dni dla {target_user_id}")
    await admin_user_manage(query, user_id, target_user_id)

async def admin_promo_all(query, user_id, days):
    """Promo - give days to ALL"""
    if user_id not in ADMIN_IDS:
        return
    
    await query.edit_message_text(f"🎁 Dodaję {days} dni WSZYSTKIM...")
    
    all_users = db.get_all_users()
    success = 0
    
    for target_user in all_users:
        target_user_id = target_user['user_id']
        
        current_expires = target_user.get('subscription_expires')
        if current_expires:
            try:
                expires_date = datetime.fromisoformat(current_expires)
            except:
                expires_date = datetime.now()
        else:
            expires_date = datetime.now()
        
        new_expires = expires_date + timedelta(days=days)
        
        target_user['subscription_expires'] = new_expires.isoformat()
        target_user['is_premium'] = True
        db.update_user(target_user_id, target_user)
        
        try:
            await query.bot.send_message(
                chat_id=target_user_id,
                text=f"""🎁 PROMOCJA SPECJALNA!

Otrzymałeś {days} dni Premium GRATIS!

💎 Dziękujemy za bycie z nami! ❤️"""
            )
            success += 1
        except:
            pass
    
    await query.edit_message_text(
        f"""✅ PROMOCJA ZAKOŃCZONA

Wysłano: {success}/{len(all_users)} użytkowników
Dni dodane: {days}""",
        reply_markup=back_button('admin_panel')
    )

# ==========================================
# TEXT MESSAGE HANDLER
# ==========================================
async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle text messages - search pairs or admin messages"""
    user_id = update.effective_user.id
    user = db.get_user(user_id)
    
    if not user:
        await update.message.reply_text("❌ Wyślij /start aby rozpocząć")
        return
    
    if user.get('awaiting_admin_message'):
        await handle_admin_message_forward(update, context, user_id, user)
        return
    
    search_term = update.message.text.strip().upper()
    exchange = user.get('selected_exchange', 'mexc').lower()
    
    await update.message.reply_text(f"🔍 Szukam '{search_term}' na {EXCHANGES[exchange]['name']}...")
    
    try:
        symbols = await exchange_api.get_symbols(exchange)
        
        if not symbols:
            await update.message.reply_text("❌ Błąd pobierania par", reply_markup=back_button())
            return
        
        matching = [s for s in symbols if search_term in s.upper()]
        
        if not matching:
            await update.message.reply_text(f"❌ Nie znaleziono par zawierających '{search_term}'", reply_markup=back_button())
            return
        
        text = f"🔍 WYNIKI WYSZUKIWANIA\n\nZnaleziono: {len(matching)} par\n\n"
        
        keyboard = []
        
        for symbol in matching[:20]:
            keyboard.append([InlineKeyboardButton(f"📊 {symbol}", callback_data=f'analyze_{symbol}')])
        
        keyboard.append([InlineKeyboardButton('⬅️ Menu', callback_data='back_main')])
        
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        
    except Exception as e:
        logger.error(f"Search error: {e}")
        await update.message.reply_text(f"❌ Błąd: {e}", reply_markup=back_button())

async def handle_admin_message_forward(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id, user):
    """Forward message to admin"""
    if not ADMIN_IDS:
        await update.message.reply_text("❌ Brak skonfigurowanego admina")
        return
    
    admin_id = ADMIN_IDS[0]
    username = update.effective_user.username or "Brak username"
    first_name = update.effective_user.first_name or "User"
    
    try:
        header = f"💬 Wiadomość od:\n\n"
        header += f"👤 {first_name} (@{username})\n"
        header += f"🆔 ID: {user_id}\n"
        header += f"{'='*30}\n\n"
        
        await context.bot.send_message(chat_id=admin_id, text=header)
        
        await update.message.forward(admin_id)
        
        await update.message.reply_text(
            "✅ Wiadomość wysłana!\n\nAdmin odpowie najszybciej jak to możliwe.",
            reply_markup=back_button()
        )
        
        user['awaiting_admin_message'] = False
        db.update_user(user_id, user)
        
    except Exception as e:
        logger.error(f"Forward error: {e}")
        await update.message.reply_text(f"❌ Błąd: {e}", reply_markup=back_button())

# ==========================================
# START FROM CALLBACK
# ==========================================
async def start_command_from_callback(query, user_id, user):
    """Start command from callback (recreate menu)"""
    sub_status = format_subscription_status(user.get('subscription_expires'), user.get('is_blocked', False))
    is_admin = user_id in ADMIN_IDS
    
    welcome = f"""👋 Elite Futures Trader Bot

Status: {sub_status}
🆔 ID: {user_id}

✨ Wpisz nazwę pary (np. BTC) aby wyszukać
📊 Lub użyj menu poniżej"""

    keyboard = [
        [InlineKeyboardButton("🔍 Wyszukaj parę", callback_data='search_pair')],
        [InlineKeyboardButton("📊 Skaner ekstremów", callback_data='scan_extremes')],
        [InlineKeyboardButton("🎯 Sygnały AI", callback_data='ai_signals')],
        [InlineKeyboardButton("🔔 Alerty", callback_data='alerts_menu')],
        [InlineKeyboardButton("⚙️ Ustawienia", callback_data='settings')],
        [InlineKeyboardButton("💎 Subskrypcja", callback_data='subscription')],
        [InlineKeyboardButton("💬 Czat z adminem", callback_data='admin_chat')],
        [InlineKeyboardButton("⭐ Oceń bota", callback_data='rate_bot')]
    ]
    
    if is_admin:
        keyboard.append([InlineKeyboardButton("👨‍💼 Admin", callback_data='admin_panel')])
    
    keyboard.append([
        InlineKeyboardButton("📊 MEXC", url='https://promote.mexc.com/r/gspEf2nl'),
        InlineKeyboardButton("📊 Bybit", url='https://www.bybit.com/invite?ref=64NXL'),
        InlineKeyboardButton("📊 Binance", url='https://www.binance.com/activity/referral-entry/CPA?ref=CPA_00J86WYYZV')
    ])
    
    await query.edit_message_text(welcome, reply_markup=InlineKeyboardMarkup(keyboard))

logger.info("✅ Handlers initialized")

# ==========================================
# SEARCH PAIR MENU
# ==========================================
async def search_pair_menu(query, user_id, user):
    """Search pair menu"""
    text = """🔍 WYSZUKAJ PARĘ

Wpisz nazwę kryptowaluty (np. BTC, ETH, SOL)

Bot znajdzie wszystkie pary z USDT na wybranej giełdzie.

💡 Możesz też wpisać nazwę w dowolnym momencie bez klikania tego przycisku!"""
    
    keyboard = [[InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
    
    user['awaiting_search'] = True
    db.update_user(user_id, user)

# ==========================================
# AI SIGNALS MENU
# ==========================================
async def ai_signals_menu(query, user_id, user):
    """AI Signals menu"""
    text = """🎯 SYGNAŁY AI

Wybierz timeframe:

Bot przeanalizuje TOP pary używając:
• DeepSeek AI - analiza techniczna
• RSI, MACD, Volume
• Support/Resistance
• Rekomendacje TP1/TP2/TP3"""
    
    keyboard = [
        [InlineKeyboardButton("📊 15m", callback_data='ai_15m'), InlineKeyboardButton("📊 1h", callback_data='ai_1h')],
        [InlineKeyboardButton("📊 4h", callback_data='ai_4h'), InlineKeyboardButton("📊 1d", callback_data='ai_1d')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

# ==========================================
# RATE BOT MENU
# ==========================================
async def rate_bot_menu(query, user_id, user):
    """Rate bot menu"""
    text = """⭐ OCEŃ BOTA

Pomóż nam się rozwijać!

📝 Twoja opinia:
• Co działa świetnie?
• Co można poprawić?
• Jakie funkcje dodać?

💬 Napisz swoją opinię w następnej wiadomości lub kliknij poniżej:"""
    
    keyboard = [
        [InlineKeyboardButton("⭐⭐⭐⭐⭐ Świetny!", callback_data='rate_5')],
        [InlineKeyboardButton("⭐⭐⭐⭐ Dobry", callback_data='rate_4')],
        [InlineKeyboardButton("⭐⭐⭐ OK", callback_data='rate_3')],
        [InlineKeyboardButton("💬 Napisz opinię", callback_data='admin_chat')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

logger.info("✅ New menu handlers added")

# ==========================================
# ADVANCED AI SIGNALS
# ==========================================
from ai_signals_advanced import advanced_ai_signals

async def ai_signals_menu_advanced(query, user_id, user):
    """Advanced AI Signals menu"""
    exchange = user.get('selected_exchange', 'mexc').lower()
    
    text = f"""🤖 SYGNAŁY AI - {EXCHANGES[exchange]['name']}

⏱ Wybierz TIMEFRAME:
(czas w jakim sygnał się sprawdzi)

📊 Skanowanie z filtrami:
• Volume + Volatility + Likwidność
• Multi-timeframe analysis
• DeepSeek AI + wskaźniki"""
    
    keyboard = [
        [InlineKeyboardButton("⚡ 1m", callback_data='ai_scan_1m'), InlineKeyboardButton("⚡ 3m", callback_data='ai_scan_3m'), InlineKeyboardButton("⚡ 5m", callback_data='ai_scan_5m')],
        [InlineKeyboardButton("📊 15m", callback_data='ai_scan_15m'), InlineKeyboardButton("📊 30m", callback_data='ai_scan_30m'), InlineKeyboardButton("📊 1h", callback_data='ai_scan_1h')],
        [InlineKeyboardButton("📈 2h", callback_data='ai_scan_2h'), InlineKeyboardButton("📈 4h", callback_data='ai_scan_4h'), InlineKeyboardButton("📈 8h", callback_data='ai_scan_8h')],
        [InlineKeyboardButton("🔥 12h", callback_data='ai_scan_12h'), InlineKeyboardButton("🔥 1d", callback_data='ai_scan_1d'), InlineKeyboardButton("🔥 3d", callback_data='ai_scan_3d')],
        [InlineKeyboardButton("💎 1w", callback_data='ai_scan_1w'), InlineKeyboardButton("💎 2w", callback_data='ai_scan_2w'), InlineKeyboardButton("💎 1M", callback_data='ai_scan_1M')],
        [InlineKeyboardButton("⚙️ Ustawienia skanowania", callback_data='ai_scan_settings')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def ai_scan_settings_menu(query, user_id, user):
    """Scan settings"""
    text = """⚙️ USTAWIENIA SKANOWANIA

Wybierz ile par przeskanować:

💡 Większa liczba = więcej sygnałów
⚠️ Większa liczba = dłuższe skanowanie"""
    
    keyboard = [
        [InlineKeyboardButton("🔟 TOP 10 par", callback_data='ai_size_top10')],
        [InlineKeyboardButton("5️⃣0️⃣ TOP 50 par", callback_data='ai_size_top50')],
        [InlineKeyboardButton("💯 TOP 100 par", callback_data='ai_size_top100')],
        [InlineKeyboardButton("2️⃣0️⃣0️⃣ TOP 200 par", callback_data='ai_size_top200')],
        [InlineKeyboardButton("3️⃣0️⃣0️⃣ TOP 300 par", callback_data='ai_size_top300')],
        [InlineKeyboardButton("🌐 WSZYSTKIE pary", callback_data='ai_size_all')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='ai_signals')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def ai_scan_select_size(query, user_id, user, timeframe):
    """Select scan size before scanning"""
    exchange = user.get('selected_exchange', 'mexc').lower()
    
    text = f"""🤖 SYGNAŁY AI - {EXCHANGES[exchange]['name']}

⏱ Timeframe: {advanced_ai_signals.timeframes.get(timeframe, timeframe)}

📊 ILE PAR PRZESKANOWAĆ?

💡 Więcej par = więcej sygnałów
⚠️ Więcej par = dłuższe skanowanie"""
    
    keyboard = [
        [InlineKeyboardButton("🔟 TOP 10 par (~5s)", callback_data=f'ai_run_{timeframe}_top10')],
        [InlineKeyboardButton("5️⃣0️⃣ TOP 50 par (~20s)", callback_data=f'ai_run_{timeframe}_top50')],
        [InlineKeyboardButton("💯 TOP 100 par (~40s)", callback_data=f'ai_run_{timeframe}_top100')],
        [InlineKeyboardButton("2️⃣0️⃣0️⃣ TOP 200 par (~80s)", callback_data=f'ai_run_{timeframe}_top200')],
        [InlineKeyboardButton("5️⃣0️⃣0️⃣ TOP 500 par (~3min)", callback_data=f'ai_run_{timeframe}_top500')],
        [InlineKeyboardButton("🌐 WSZYSTKIE pary (~5min)", callback_data=f'ai_run_{timeframe}_all')],
        [InlineKeyboardButton('⬅️ Powrót', callback_data='ai_signals')]
    ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def ai_scan_execute(query, user_id, user, timeframe, scan_size="top10"):
    """Execute AI scan"""
    exchange = user.get('selected_exchange', 'mexc').lower()
    # scan_size passed as parameter
    
    await query.edit_message_text(f"""🤖 SKANOWANIE AI...

⏱ Timeframe: {advanced_ai_signals.timeframes.get(timeframe, timeframe)}
🌐 Giełda: {EXCHANGES[exchange]['name']}
📊 Zakres: {scan_size.upper()}

⏳ Proszę czekać...""")
    
    try:
        results = await advanced_ai_signals.scan_with_filters(exchange, timeframe, scan_size)
        
        if not results:
            await query.edit_message_text("❌ Brak sygnałów spełniających kryteria", reply_markup=back_button('ai_signals'))
            return
        
        text = f"""🤖 SYGNAŁY AI - {EXCHANGES[exchange]['name']}

⏱ Timeframe: {advanced_ai_signals.timeframes.get(timeframe, timeframe)}
📊 Znaleziono: {len(results)} sygnałów

TOP SYGNAŁY:

"""
        
        for r in results[:10]:
            emoji = "🟢" if r['signal'] == 'LONG' else "🔴"
            text += f"""{emoji} {r['symbol']} | {r['signal']} {r['confidence']}%
Entry: ${r['entry']:.4f} | TP: ${r['tp1']:.4f}
Powód: {', '.join(r['reasons'])}

"""
        
        keyboard = [
            [InlineKeyboardButton('🔄 Odśwież', callback_data=f'ai_scan_{timeframe}')],
            [InlineKeyboardButton('⚙️ Ustawienia', callback_data='ai_scan_settings')],
            [InlineKeyboardButton('⬅️ Powrót', callback_data='ai_signals')]
        ]
        
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        
        user['signals_count'] = user.get('signals_count', 0) + len(results)
        db.update_user(user_id, user)
        
    except Exception as e:
        logger.error(f"AI scan error: {e}")
        await query.edit_message_text(f"❌ Błąd: {e}", reply_markup=back_button('ai_signals'))

logger.info("✅ Advanced AI Signals handlers added")

# ==========================================
# CENTRALNY ANALYZER - DETAILED VIEW
# ==========================================
from central_ai_analyzer import central_analyzer
from languages import t, get_user_language, TRANSLATIONS

async def show_pair_analysis(query, user_id, user, symbol, exchange, timeframe, context='general'):
    """
    GŁÓWNA FUNKCJA - Pokaż pełną analizę pary
    Wywołana z KAŻDEGO miejsca w bocie (search, scan, ai_signal)
    """
    
    # Show loading
    await query.edit_message_text(f"""🤖 ANALIZA AI - {symbol}

⏳ Analizuję...

📊 Pobieranie danych z giełdy
🔍 Analiza techniczna (RSI, EMA, MACD...)
📈 Wykrywanie struktur rynku
💎 DeepSeek AI reasoning
📰 Sprawdzanie newsów

Proszę czekać ~10 sekund...""")
    
    try:
        # CALL CENTRAL ANALYZER
        analysis = await central_analyzer.analyze_pair_full(
            exchange=exchange,
            symbol=symbol,
            timeframe=timeframe,
            context=context
        )
        
        if not analysis:
            await query.edit_message_text(
                f"❌ Nie udało się przeanalizować {symbol}",
                reply_markup=back_button('back_main')
            )
            return
        
        # Build beautiful report with user's language
        lang = get_user_language(user)
        text = format_analysis_report(analysis, lang)
        
        # Buttons
        keyboard = [
            [InlineKeyboardButton('🔄 Odśwież analizę', callback_data=f'analyze_{symbol}_{timeframe}')],
            [
                InlineKeyboardButton('⏱ 15m', callback_data=f'analyze_{symbol}_15m'),
                InlineKeyboardButton('⏱ 1h', callback_data=f'analyze_{symbol}_1h'),
                InlineKeyboardButton('⏱ 4h', callback_data=f'analyze_{symbol}_4h')
            ],
            [InlineKeyboardButton('📊 Więcej wskaźników', callback_data=f'details_{symbol}_{timeframe}')],
            [InlineKeyboardButton('⬅️ Powrót', callback_data='back_main')]
        ]
        
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        
        # Increment counter
        user['signals_count'] = user.get('signals_count', 0) + 1
        db.update_user(user_id, user)
        
    except Exception as e:
        logger.error(f"Analysis display error: {e}")
        await query.edit_message_text(
            f"❌ Błąd analizy: {e}",
            reply_markup=back_button('back_main')
        )

def format_analysis_report(analysis, lang='pl'):
    """Format analysis into beautiful Telegram message with explanations"""
    
    symbol = analysis['symbol']
    signal = analysis['signal']
    technical = analysis['technical']
    sentiment = analysis['sentiment']
    structure = analysis['structure']
    volume = analysis['volume']
    
    # Header
    direction_emoji = "🟢" if signal['direction'] == 'LONG' else "🔴" if signal['direction'] == 'SHORT' else "⚪"
    
    text = f"""{direction_emoji} {t('signal', lang)} AI - {symbol}

{'='*30}
🎯 SYGNAŁ: {signal['direction']} ({signal['confidence']}%)
{'='*30}

💰 CENA: ${technical['price']:.6f}
📊 Zmiana 24h: {technical['change_24h']:+.2f}%

🎯 REKOMENDACJE:
• Entry: ${signal['entry']:.6f}
• TP1: ${signal['tp1']:.6f} (+{((signal['tp1']/signal['entry']-1)*100):.1f}%)
• TP2: ${signal['tp2']:.6f} (+{((signal['tp2']/signal['entry']-1)*100):.1f}%)
• TP3: ${signal['tp3']:.6f} (+{((signal['tp3']/signal['entry']-1)*100):.1f}%)
• Stop Loss: ${signal['sl']:.6f}
• R/R Ratio: {signal['rr_ratio']:.2f}

"""
    
    # Sentiment
    text += f"""📈 SENTYMENT RYNKU:
{sentiment['label']} ({sentiment['score']:+d}/100)

"""
    
    # Technical indicators
    rsi = technical['rsi']['14']
    text += f"""🔧 WSKAŹNIKI TECHNICZNE:
• RSI(14): {rsi:.1f} {"🔥 Oversold" if rsi < 30 else "💎 Overbought" if rsi > 70 else ""}
• EMA(9): ${technical['ema']['9']:.2f}
• EMA(21): ${technical['ema']['21']:.2f}
• MACD: {technical['macd']['histogram']:.2f}

"""
    
    # Volume
    text += f"""📊 WOLUMEN:
• Ratio: {volume['ratio']:.2f}x średniej
• Buying pressure: {volume['buy_pressure']:.0f}%
• Selling pressure: {volume['sell_pressure']:.0f}%

"""
    
    # Support/Resistance
    if structure.get('support'):
        text += f"""📍 SUPPORT/RESISTANCE:
• Support: ${structure['support'][0]:.4f}
• Resistance: ${structure['resistance'][0]:.4f}

"""
    
    # AI Reasoning
    text += f"""🤖 AI REASONING:
"""
    for reason in signal['reasons'][:5]:
        text += f"• {reason}\n"
    
    text += f"""
⏱ Timeframe: {analysis['timeframe']}
🌐 Exchange: {analysis['exchange'].upper()}
🕐 {datetime.now().strftime('%H:%M:%S')}

{'='*30}
📚 PROSTE WYJAŚNIENIA:
{'='*30}

{t('explain_rsi', lang)}

{t('explain_ema', lang)}

{t('explain_volume', lang)}

💡 TP1/TP2/TP3 = Cele zysku (Take Profit)
💡 Stop Loss = Poziom zamknięcia straty
💡 R/R Ratio = Stosunek zysku do ryzyka

{'='*30}
{t('disclaimer', lang)}
{'='*30}
"""
    
    return text

logger.info("✅ Central analyzer handlers added")

# ==========================================
# LANGUAGE SETTINGS
# ==========================================
async def language_menu(query, user_id, user):
    """Language selection menu"""
    from languages import LANGUAGES
    
    text = """🌍 WYBIERZ JĘZYK / SELECT LANGUAGE

Wybierz swój język:
Select your language:"""
    
    keyboard = []
    for lang_code, lang_data in LANGUAGES.items():
        keyboard.append([InlineKeyboardButton(lang_data['name'], callback_data=f'set_lang_{lang_code}')])
    
    keyboard.append([InlineKeyboardButton('⬅️ Powrót / Back', callback_data='settings')])
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

logger.info("✅ Language menu added")
