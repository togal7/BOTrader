import anthropic
import requests
from config import logger

class AITrader:
    def __init__(self, deepseek_key, perplexity_key):
        self.deepseek_key = deepseek_key
        self.perplexity_key = perplexity_key
        self.client = anthropic.Anthropic(api_key=deepseek_key)
    
    async def analyze_with_deepseek(self, symbol, data):
        """DeepSeek analysis"""
        try:
            prompt = f"Analyze {symbol}: Price {data.get('price')}, RSI {data.get('rsi')}"
            
            message = self.client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}]
            )
            
            return {
                'signal': 'LONG',
                'confidence': 75,
                'reason': message.content[0].text[:200],
                'analysis': message.content[0].text
            }
        except Exception as e:
            logger.error(f"DeepSeek error: {e}")
            return None
    
    async def analyze_with_perplexity(self, symbol):
        """Perplexity market context"""
        try:
            headers = {
                'Authorization': f'Bearer {self.perplexity_key}',
                'Content-Type': 'application/json'
            }
            data = {
                'model': 'llama-3.1-sonar-small-128k-online',
                'messages': [{'role': 'user', 'content': f'Market news for {symbol}'}]
            }
            
            response = requests.post(
                'https://api.perplexity.ai/chat/completions',
                headers=headers,
                json=data,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                return {'market_context': result['choices'][0]['message']['content'][:300]}
        except Exception as e:
            logger.error(f"Perplexity error: {e}")
        return None
    
    async def get_ai_analysis(self, symbol, data):
        """Combined AI analysis"""
        deepseek_result = await self.analyze_with_deepseek(symbol, data)
        perplexity_result = await self.analyze_with_perplexity(symbol)
        
        if not deepseek_result and not perplexity_result:
            return {
                'signal': 'WAIT',
                'confidence': 0,
                'reason': 'Brak danych',
                'analysis': 'AI unavailable'
            }
        
        if deepseek_result:
            result = deepseek_result
            if perplexity_result:
                result['market_context'] = perplexity_result.get('market_context', '')
            return result
        
        return perplexity_result

ai_trader = AITrader('', '')
logger.info("✅ AI Trader initialized")
