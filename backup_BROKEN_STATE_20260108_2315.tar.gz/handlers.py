from telegram import Update
from telegram.ext import ContextTypes
from config import logger, ADMIN_ID
from database import db
from keyboards import *
from utils import *
from exchanges import exchange_api
from ai_trader import ai_trader

# ============================================
# START
# ============================================

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Komenda /start"""
    user = update.effective_user
    db.get_user(user.id)  # Rejestruje użytkownika
    
    user_data = db.get_user(user.id)
    sub_status = format_subscription_status(user_data['subscription_end'], user_data['is_blocked'])
    
    is_admin = user.id == ADMIN_ID
    
    welcome = f"""👋 **Witaj w Elite Futures Trader Bot*

📊 **Twój status:** {sub_status}
🆔 **ID:** """
