#!/usr/bin/env python3
import asyncio
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from config import logger, TELEGRAM_BOT_TOKEN
from handlers import *
from exchanges import exchange_api

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    """Obsługa błędów"""
    logger.error(f"Exception: {context.error}", exc_info=context.error)

async def shutdown(application: Application):
    """Zamykanie zasobów"""
    logger.info("Zamykanie bota...")
    await exchange_api.close()

def main():
    """Główna funkcja bota"""
    logger.info("🚀 Uruchamianie Elite Futures Trader Bot...")
    
    # Aplikacja
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    
    # Handlery komend
    application.add_handler(CommandHandler("start", start_command))
    
    # Callback queries
    application.add_handler(CallbackQueryHandler(button_callback))
    
    # Error handler
    application.add_error_handler(error_handler)
    
    # Shutdown
    application.post_shutdown = shutdown
    
    # Start polling
    logger.info("✅ Bot uruchomiony!")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
